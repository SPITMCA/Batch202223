# mentor_Me_Senpai

Mentor me Senpai is a website to share interview experiences which will be taken as input through a form and stored in the database.
Share bugs if you find any @ritikm099@gmail.com

# Setup -

1. Install Node JS. Run 'node -v' to verify node js installed.
2. Run 'npm install' from command prompt to download dependent modules.
3. Download and install mongodb.
4. Start run 'mongod.exe' from bin directory where the mongodb is installed.
5. MongoDB run at 27017 port by default.
6. Update ReviewDAO.js to connect mongodb with username and password.
7. Run 'node server.js' in command prompt from project directory.
8. Open 'http://localhost:8080' to verify server started.
